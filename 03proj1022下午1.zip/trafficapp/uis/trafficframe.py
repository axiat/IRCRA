from PyQt5.QtWidgets import QDialog
from trafficapp.uis.trafficui import Ui_Traffic

class WTrafficDialog(QDialog):
    def __init__(self):
        super(WTrafficDialog, self).__init__()
        self.ui = Ui_Traffic()
        self.ui.setupUi(self)
        self.ui.lbl_video_1.clicked.connect(self.switch_video1_main)
        self.ui.lbl_video_2.clicked.connect(self.switch_video2_main)
        self.ui.lbl_video_3.clicked.connect(self.switch_video3_main)
        self.ui.lbl_video_4.clicked.connect(self.switch_video4_main)
        self.ui.lbl_video_5.clicked.connect(self.switch_video5_main)
        self.ui.lbl_video_6.clicked.connect(self.switch_video6_main)
        self.ui.lbl_video_7.clicked.connect(self.switch_video7_main)


    # 其他交互与逻辑处理
    def switch_video1_main(self):
        print("切换街口的视频：", 1)
    def switch_video2_main(self):
        print("切换街口的视频：", 2)
    def switch_video3_main(self):
        print("切换街口的视频：", 3)
    def switch_video4_main(self):
        print("切换街口的视频：", 4)
    def switch_video5_main(self):
        print("切换街口的视频：", 5)
    def switch_video6_main(self):
        print("切换街口的视频：", 6)
    def switch_video7_main(self):
        print("切换街口的视频：", 7)
    

    def handle_video(self, btn_id):
        print("打开的按钮id：", btn_id)
        if btn_id == 100:
            pass
        if btn_id == 101:
            pass
        if btn_id == 102:
            pass
        if btn_id == 103:
            pass    

    def modify_bright(self, val):
        print("调整亮度值：", val)
